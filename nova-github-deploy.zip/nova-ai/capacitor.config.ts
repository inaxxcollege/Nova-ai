import type {CapacitorConfig} from '@capacitor/cli';const config:CapacitorConfig={appId:'ai.nova.assistant',appName:'NOVA AI',webDir:'dist',server:{androidScheme:'https'}};export default config;
