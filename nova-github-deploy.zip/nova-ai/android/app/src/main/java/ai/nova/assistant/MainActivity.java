package ai.nova.assistant;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
