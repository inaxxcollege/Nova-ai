# NOVA AI

A responsive, mobile-first NOVA assistant workspace. Visual direction follows the referenced Behance case study's dark, minimal mobile composition, restrained purple glow/orb, spacious type and card-based quick actions; the interface and branding are original.

## Run locally

Requirements: Node.js 20+. Android APK packaging additionally requires Android Studio / Android SDK and Java 17+.

```bash
npm install
cp .env.example .env
# Add a server-side GROQ_API_KEY or OPENAI_API_KEY to .env
npm run server
# In a second terminal
npm run dev
```

Open the Vite URL (default http://localhost:5173). The Vite dev server proxies `/api` to the API server on port 3001. The app works without a key for navigation and local conversations; real AI replies require `OPENAI_API_KEY`. Set `OPENAI_MODEL` to a model available to your account. Keys must remain in server `.env`; never put them in `VITE_*` variables.

## Deploy

Deploy frontend and API behind one origin, or configure a same-origin `/api` reverse proxy to the Node service. Set `OPENAI_API_KEY`, `OPENAI_MODEL`, `PORT`, and `APP_ORIGIN` as server secrets. Build frontend with `npm run build`; serve `dist/` via a static host and route `/api/*` to `npm run server`. Use HTTPS. Set strict origin/CORS policy, request rate limits, auth, logging and monitoring at the deployment boundary before public launch.

## Implementation checklist

- [x] Five primary destinations and responsive phone bottom navigation.
- [x] Home, quick action prompts, recent chats and pinned department entry.
- [x] Real provider-backed chat API adapter (OpenAI-compatible), timeout, validation, bounded input and provider error surfacing; no fake response fallback.
- [x] Local conversation persistence, history, new chat, delete, JSON export.
- [x] Nine dedicated discover/workspace screens and prompt starters.
- [x] Voice screen; microphone permission and browser speech recognition with unsupported/error fallback.
- [x] Attachment selection and graceful setup notices.
- [x] Settings with persistent Midnight, Ocean, Rose and Light theme choices; orb hue and motion preferences; local data export/deletion; reduced-motion support.
- [x] Optional real web research via a server-side Tavily adapter, query validation, timeout, summaries and cited result links (requires `TAVILY_API_KEY`).
- [x] GitHub Pages workflow for the static frontend, repository-path base handling, configurable API origin.
- [x] PWA manifest, responsive safe-area navigation.
- [ ] Authenticated accounts, cloud persistence/RLS, server-side user authorization, uploads and cross-device sync.
- [ ] Streaming, markdown/code rendering, edit/rename/pin/search history, provider fallback and quotas.
- [x] Browser speech synthesis for voice replies where supported.
- [ ] Image generation, document parsing/generation, calendar/integration execution, and dedicated provider-backed implementations for remaining workspaces.
- [ ] Production rate limiting, security audit, automated test suite and deployment verification.

## Security and limitations

This starter is a functional local-first MVP, not a production-secure multi-user service. Conversation data stays in browser localStorage, which is not account-isolated and is not suitable for sensitive data. The API route validates input and keeps provider secrets server-side, but production must add authentication, per-user authorization, rate limits, stronger abuse controls and secure file upload storage. File selection currently does not upload or analyze files. Speech recognition depends on browser support and user permission; no background listening. There is no native application bridge. No generated code is executed. Do not use the local demo for secrets or regulated information.

## API

`POST /api/chat` JSON: `{ "messages": [{"role":"user|assistant","content":"..."}] }`. Success returns `{ "content": "...", "model": "..." }`. Health: `GET /api/health`. Provider errors and missing configuration return HTTP errors; no hard-coded AI answers are used.

## Standalone HTML file

`nova.html` is a single-file local chat interface with the NOVA symbol + wordmark and local history. It calls `/api/chat`; serve it from the same web origin as the API for live responses. Opening it directly via `file://` shows the UI but browser security prevents its API call. The full React application remains the recommended deployable app.

## Android APK packaging

Capacitor Android project is included in `android/` with app id `ai.nova.assistant`.

1. Install Android Studio and Android SDK (API 23+), plus Java 17.
2. Install packages, then build and sync web assets:
   ```bash
   npm install
   npm run build
   npx cap sync android
   ```
3. Open the project: `npx cap open android` (or Android Studio → Open → select this repository's `android` folder).
4. For a test APK: Android Studio → Build → Build Bundle(s) / APK(s) → Build APK(s). Gradle CLI alternative from the Android project: `./gradlew assembleDebug`; debug APK is `android/app/build/outputs/apk/debug/app-debug.apk`.
5. For Play Store or distribution, create a signed release in Android Studio (Build → Generate Signed Bundle / APK), protect the signing keystore, and use HTTPS for the API.

This workspace has no Android SDK/Gradle installation, so an APK binary could not be built or tested here. Build it using the included Capacitor project on a machine with Android Studio/SDK. For production, provide a deployed API origin and configure Capacitor's server/API networking; do not embed AI credentials in the mobile application.

## Credential safety notice

If a provider key was pasted or attached in a message, treat it as compromised: revoke/rotate it in the provider console now. Put only the replacement in your private server environment, never in the frontend, APK, repository, or shared files. This project intentionally does not save the supplied key.

## GitHub Pages frontend deployment

The repository includes `.github/workflows/pages.yml` for static frontend deployment. Push to the `main` branch, then in GitHub open **Settings → Pages → Build and deployment** and select **GitHub Actions**. Add repository variable `VITE_API_BASE_URL` containing the HTTPS origin of your separately deployed NOVA API (for example `https://your-api.example.com`, no trailing slash). The API must permit the Pages origin in `APP_ORIGIN`; provider keys remain server-side on that API host. GitHub Pages does not run Express, so the app's AI and web research endpoints will not work until the backend is deployed elsewhere. Set the API host's `APP_ORIGIN` to the site origin such as `https://YOURNAME.github.io` (CORS origin excludes the `/repository` path).

A GitHub personal access token is not needed for these instructions. Never paste a PAT or provider secret into chat or commit one to the repo. Enable Pages with GitHub's repository Settings and the Actions workflow instead.

### Live research integration

The Research Lab now has a real web search endpoint. Configure `TAVILY_API_KEY` server-side to enable it; otherwise the interface displays a setup message rather than mock search results. Search responses include a provider summary (when available) and links/snippets from the returned sources. Search requests are limited to a 500-character query and have a timeout. Verify claims against linked pages.
